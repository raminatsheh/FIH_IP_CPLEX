import java.util.ArrayList;

import lpsolve.*;

public class Solver {
	
	private LpSolve solver;
	private int sigma_min=2;

	public void minimize(int[][] linear_Program_Matrice) {
		
		try {
			
			solver = LpSolve.makeLp(0, linear_Program_Matrice[0].length);
			
			String temp_string = "";
			
			//rename variables
			for (int i =0; i<linear_Program_Matrice[0].length; i++){
				int t = i+1;
				String temp = "x"+t;
				solver.setColName(t, temp);
			}
			solver.setAddRowmode(true);  /* makes building the model faster if it is done rows by row */
			
			for (int i =0; i<linear_Program_Matrice.length;i++)
			{
				int temp_sum = 0;
				for (int j=0; j<linear_Program_Matrice[i].length;j++)
				{
					temp_sum = linear_Program_Matrice[i][j]+temp_sum;
					if (j==linear_Program_Matrice[i].length){
						temp_string = temp_string + linear_Program_Matrice[i][j];

					}
					else{
					temp_string = temp_string + linear_Program_Matrice[i][j]+" ";
					}
				}
				
				
				solver.strAddConstraint(temp_string, LpSolve.GE, temp_sum-sigma_min+1);
				temp_sum = 0;
				temp_string = "";
				

			}
			
			for (int j2 =0;j2<linear_Program_Matrice[0].length;j2++ ){
				solver.setBinary((j2+1), true);
			}
			
			String temp_string1 = "1";
			for (int j2 =1;j2<linear_Program_Matrice[0].length;j2++ ){
				temp_string1 = temp_string1 + " 1";
			}
			solver.setAddRowmode(false);			
		      // set objective function
		      solver.strSetObjFn(temp_string1);
		      solver.setMinim();

		solver.solve();
      // print solution
      System.out.println("Value of objective function: " + solver.getObjective());
      double[] var = solver.getPtrVariables();
      for (int i1 = 0; i1 < var.length; i1++) {
        System.out.println("Value of var[" + i1 + "] = " + var[i1]);
      }

      // delete the problem and free memory
      solver.deleteLp();
			
		} catch (LpSolveException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void sanitize_transaction(ArrayList<Itemset> transaction, ArrayList<Integer> items) {
		
		try {
			
			solver = LpSolve.makeLp(0, (transaction.size()+items.size()));
			
			String temp_string = "";
			
			//rename variables
			for (int i =0; i<transaction.size(); i++){
				int t = i+1;
				String temp = "";
				if (transaction.get(i).get_type()=="sensitive")
				{
					temp = "x"+t;
				}
				else{
					temp = "v"+t;
				}
				solver.setColName(t, temp);
			}
			
			solver.setAddRowmode(true);  /* makes building the model faster if it is done rows by row */
			
			for (int i =0; i<transaction.size();i++)
			{
				int temp_sum = 0;
				
				if (i != 0){
					for (int j = 0; j<i;j++){
						temp_string = temp_string + "0 ";
					}
				}
		
				if (transaction.get(i).get_type()== "sensitive"){
					temp_string = temp_string + "0 ";
				}
				else{
					int t = -1;
					for (Integer temp: transaction.get(i).items){
						if (Main.list_of_sensitive_items.contains(temp)){
							t = t-1;
						}
					}
					temp_string = temp_string + Integer.toString(t) + " ";
				}
				
				if (i <= transaction.size()){
					for (int j = i; j<transaction.size()-1;j++){
						temp_string = temp_string + "0 ";
					}
				}
				
				if (true){
					for (int j=0; j<items.size(); j++){
						if (Main.list_of_sensitive_items.contains(items.get(j)) && transaction.get(i).items.contains(items.get(j))){
							if (j == items.size()){
								temp_string = temp_string+"1";
							}
							else{
								temp_string = temp_string+"1 ";
							}

						}
						else{
							if (j == items.size()){
								temp_string = temp_string+"0";
							}
							else{
								temp_string = temp_string+"0 ";
							}
						}
					}
				}
				if (transaction.get(i).get_type()== "sensitive"){
					solver.strAddConstraint(temp_string, LpSolve.GE, 1);
				}
				else{
					solver.strAddConstraint(temp_string, LpSolve.LE, 0);
				}
				
				temp_sum = 0;
				temp_string = "";
			}
			
			for (int j2 =0;j2<(transaction.size()+items.size());j2++ ){
				solver.setBinary((j2+1), true);
			}
			
			String temp_string1 = "1";
			for (int j2 =1;j2<(transaction.size()+items.size());j2++ ){
				if (j2 >= transaction.size()){
					temp_string1 = temp_string1 + " 0";
				}
				else{
					temp_string1 = temp_string1 + " 1";
				}
			}
			solver.setAddRowmode(false);			
		      // set objective function
		      solver.strSetObjFn(temp_string1);
		      solver.setMinim();

		solver.solve();
      // print solution
      System.out.println("Value of objective function: " + solver.getObjective());
      double[] var = solver.getPtrVariables();
      for (int i1 = 0; i1 < var.length; i1++) {
        System.out.println("Value of var[" + i1 + "] = " + var[i1]);
      }

      // delete the problem and free memory
      solver.deleteLp();
			
		} catch (LpSolveException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


}
