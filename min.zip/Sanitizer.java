import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;


public class Sanitizer {
	
    /** the list of current itemsets */
    private List<int[]> itemsets ;
    private List<int[]> all_itemsets_in_T ;
    private List<Itemset> all_itemsets_in_T_Itemset = new ArrayList<Itemset>();
    private Solver transaction_solver = new Solver();
    
	public void sanitize_transaction(Itemset transaction){
		
		populate_itemsets_in_T(transaction);
		convert_to_Itemsets();
		keep_only_relevant_itemsets();
		transaction_solver.sanitize_transaction((ArrayList<Itemset>) this.all_itemsets_in_T_Itemset, transaction.items);
	}
	
	private void convert_to_Itemsets(){
		for (int[] temp_int_array: all_itemsets_in_T){
			ArrayList<Integer> temp_AL_Integer = new ArrayList<Integer>();
			for (int i:temp_int_array){
				temp_AL_Integer.add((Integer) i);
			}
			
			Itemset temp_itemset = new Itemset(1, temp_AL_Integer, "temp");
			for (Itemset temp_itemset2:Main.list_of_sensitive_itemsets){
				if (temp_itemset.Contains(temp_itemset2)){
					temp_itemset.set_type("sensitive");
				}
			}

			all_itemsets_in_T_Itemset.add(temp_itemset);
		}
	}



	private void keep_only_relevant_itemsets() {
		ArrayList<Itemset> temp_remove = new ArrayList<Itemset>();
		for (Itemset temp_itemset:all_itemsets_in_T_Itemset){
		
			boolean exists = false;
			
			for (Itemset temp_itemset2:Main.list_of_preprocessed_itemsts){
				if(temp_itemset2.Contains(temp_itemset)){
					exists = true;
				}
			}
			
			if (!exists){
				temp_remove.add(temp_itemset);
			}
		}
		
		for (Itemset temp_itemset:temp_remove){
			all_itemsets_in_T_Itemset.remove(temp_itemset);
		}
	}




	private void populate_itemsets_in_T(Itemset transaction) {
		this.createItemsetsOfSize1(transaction);
		this.createNewItemsetsFromPreviousOnes();
		all_itemsets_in_T = itemsets;
		
		for (int i =0; i < transaction.items.size()-2;i++){
			this.createNewItemsetsFromPreviousOnes();
			all_itemsets_in_T.addAll(itemsets);
		}
	}
    
    
    
    
	private void createItemsetsOfSize1(Itemset transaction) {
		itemsets = new ArrayList<int[]>();
        for(Integer temp:transaction.items)
        {
        	int[] cand = {temp.intValue()};
        	itemsets.add(cand);
        }
	}
	
	 private void createNewItemsetsFromPreviousOnes()
	    {
	    	// by construction, all existing itemsets have the same size
	    	int currentSizeOfItemsets = itemsets.get(0).length;
	    	//log("Creating itemsets of size "+(currentSizeOfItemsets+1)+" based on "+itemsets.size()+" itemsets of size "+currentSizeOfItemsets);
	    		
	    	HashMap<String, int[]> tempCandidates = new HashMap<String, int[]>(); //temporary candidates
	    	
	        // compare each pair of itemsets of size n-1
	        for(int i=0; i<itemsets.size(); i++)
	        {
	            for(int j=i+1; j<itemsets.size(); j++)
	            {
	                int[] X = itemsets.get(i);
	                int[] Y = itemsets.get(j);

	                assert (X.length==Y.length);
	                
	                //make a string of the first n-2 tokens of the strings
	                int [] newCand = new int[currentSizeOfItemsets+1];
	                for(int s=0; s<newCand.length-1; s++) {
	                	newCand[s] = X[s];
	                }
	                    
	                int ndifferent = 0;
	                // then we find the missing value
	                for(int s1=0; s1<Y.length; s1++)
	                {
	                	boolean found = false;
	                	// is Y[s1] in X?
	                    for(int s2=0; s2<X.length; s2++) {
	                    	if (X[s2]==Y[s1]) { 
	                    		found = true;
	                    		break;
	                    	}
	                	}
	                	if (!found){ // Y[s1] is not in X
	                		ndifferent++;
	                		// we put the missing value at the end of newCand
	                		newCand[newCand.length -1] = Y[s1];
	                	}
	            	
	            	}
	                
	                // we have to find at least 1 different, otherwise it means that we have two times the same set in the existing candidates
	                assert(ndifferent>0);
	                
	                
	                if (ndifferent==1) {
	                    // HashMap does not have the correct "equals" for int[] :-(
	                    // I have to create the hash myself using a String :-(
	                	// I use Arrays.toString to reuse equals and hashcode of String
	                	Arrays.sort(newCand);
	                	tempCandidates.put(Arrays.toString(newCand),newCand);
	                }
	            }
	        }
	        
	        //set the new itemsets
	        itemsets = new ArrayList<int[]>(tempCandidates.values());
	    	//log("Created "+itemsets.size()+" unique itemsets of size "+(currentSizeOfItemsets+1));

	    }


}
