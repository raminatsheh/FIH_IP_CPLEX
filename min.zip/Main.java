import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;




public class Main {


	public static ArrayList<Itemset> list_of_sensitive_itemsets = new ArrayList<Itemset>();
	public static ArrayList<Itemset> list_of_all_itemsets = new ArrayList<Itemset>();
	//public static ArrayList<Itemset> list_of_relevant_itemsets = new ArrayList<Itemset>();
	public static ArrayList<Itemset> list_of_relevant_transactions = new ArrayList<Itemset>();
	public static ArrayList<Itemset> list_of_itemsets_in_relevant_transactions = new ArrayList<Itemset>();
	public static ArrayList<Itemset> list_of_preprocessed_itemsts = new ArrayList<Itemset>();
	public static ArrayList<Itemset> list_of_all_transactions = new ArrayList<Itemset>();
	public static ArrayList<Integer> list_of_sensitive_items = new ArrayList<Integer>();
	public static int number_of_sensitive_itemsets = 30; 
	public static int number_of_transactions = 10;
	public int number_of_relevant_transactions = 0;
	public static Main_Matrice my_matrice = new Main_Matrice(number_of_transactions, number_of_sensitive_itemsets);
	public String database_path = "C:\\Users\\Rami\\workspace\\Minimizing_Non_Frequent_Itemsets\\IP_Data.txt";
	public String sensitive_itemsets_path = "C:\\Users\\Rami\\workspace\\Minimizing_Non_Frequent_Itemsets\\IP_Sensitive.txt";
	public String relevant_transactions_database = "C:\\Users\\Rami\\workspace\\Minimizing_Non_Frequent_Itemsets\\IP_Data_Relevant.txt";
	public static Solver my_solver = new Solver();
	public String minimum_support_level = "0.2";
	public static double minimum_support_double;
	public static double minimum_support_level_value_double = 0.2 * number_of_transactions;
	public static Preprocessor my_preprocessor = new Preprocessor();
	public static Sanitizer my_sanitizer = new Sanitizer();
	
	
	public static void main(String[] args) throws Exception {
		Main Main_obj = new Main();
		Main_obj.Main_Program();
	}
	
	public void Main_Program() throws Exception{
		//this.populate_sensitive_itemsets();
		this.read_sensitive_itemsets(sensitive_itemsets_path);
		this.list_of_sensitive_items = this.find_sensitive_items(Main.list_of_sensitive_itemsets);
		list_of_all_itemsets = this.find_all_itemsets(database_path, minimum_support_level);
		this.populate(database_path);
		this.populate_relevant_transactions_database(relevant_transactions_database);
		minimum_support_double = (double) (list_of_all_transactions.size()*0.2/list_of_relevant_transactions.size());
		//minimum_support_integer = (int) (minimum_support_integer/list_of_relevant_transactions.size());
		list_of_itemsets_in_relevant_transactions = this.find_all_itemsets(relevant_transactions_database, Double.toString(minimum_support_double));
		list_of_preprocessed_itemsts = Main.my_preprocessor.pre_process_itemsets(list_of_all_itemsets, list_of_itemsets_in_relevant_transactions, list_of_sensitive_itemsets, list_of_sensitive_items);
		//print_array_list(Main.my_preprocessor.pre_processed_itemsets);
		my_sanitizer.sanitize_transaction(list_of_relevant_transactions.get(1));
		Main.my_matrice.solve();
	}
	
	// function that will populate the Main_Matrice


	private void print_array_list(ArrayList<Itemset> pre_processed_itemsets) {
		for (Itemset temp : pre_processed_itemsets)
		{
			System.out.println(temp.items);
		}
		
	}

	private ArrayList<Itemset> find_all_itemsets(String database_path2,
			String Support_Level) throws Exception {
		String[] args={database_path2, Support_Level};
		//new Apriori(args, this);
		Apriori my_apriori = new Apriori(args, true);
		ArrayList<Itemset> all_itemsets = my_apriori.Apriori_Itemset(args);
		return all_itemsets;
		
	}

	public Boolean populate(String passed_database_file_path) {
		try {
			String Database = passed_database_file_path;
			// Start reading the file line by line
			BufferedReader Database_Reader = new BufferedReader(new FileReader(
					Database));
			// Temp string and Itemset
			String transaction_in;
			Itemset Itemset_In;


			
			// get all the items from string and store them in the arraylist as
			// integers
			while ((transaction_in = Database_Reader.readLine()) != null) {

				// Temp array list to hold items for the itemsets that will be
				// created
				ArrayList<Integer> items_integer = new ArrayList<Integer>();
				
				String[] items_strings = transaction_in.split(" ");
				for (String item_string : items_strings) {
					items_integer.add(Integer.valueOf(item_string));
				}
				// Create the new itemset
				Itemset_In = new Itemset(0, items_integer, "Normal");
				
				//add transaction to list of all transactions
				Main.list_of_all_transactions.add(Itemset_In);
				
				//if itemset contains sensitive itemsets add it to relevant transactions
				
				for (Itemset temp : Main.list_of_sensitive_itemsets){
					if (Itemset_In.Contains(temp)){
						Main.list_of_relevant_transactions.add(Itemset_In);
						break;
					}
				}
			
			}
			Database_Reader.close();
		} catch (IOException e) {
			System.err.println("Error: " + e);
		}
		return null;
	}


	public void read_sensitive_itemsets(String passed_sensitive_itemsets_path){
		try {
			String Database = passed_sensitive_itemsets_path;
			// Start reading the file line by line
			BufferedReader Database_Reader_Sensitive = new BufferedReader(new FileReader(
					Database));
			// Temp string and Itemset
			String transaction_in;

			// get all the items from string and store them in the arraylist as
			// integers
			while ((transaction_in = Database_Reader_Sensitive.readLine()) != null) {
				
				ArrayList<Integer> items_integer = new ArrayList<Integer>();
				String[] items_strings = transaction_in.split(" ");
				for (String item_string : items_strings) {
					items_integer.add(Integer.valueOf(item_string));
					
				}
				// Create the new itemset
				//Itemset_In = new Itemset(0, items_integer, "Normal");
				Itemset temp_itemset = new Itemset(0, items_integer, "Normal");
				Main.list_of_sensitive_itemsets.add(temp_itemset);
			}
			Database_Reader_Sensitive.close();
			Main.number_of_sensitive_itemsets = Main.list_of_sensitive_itemsets.size();
		} catch (IOException e) {
			System.err.println("Error: " + e);
		}

	}
	
	public ArrayList<Integer> find_sensitive_items(ArrayList<Itemset> sensitive_itemsets){
		ArrayList<Integer> sensitive_items = new ArrayList<Integer>();
		for (Itemset sen_itemset: sensitive_itemsets){
			for (Integer sen_item: sen_itemset.items){
				if (sensitive_items.contains(sen_item)){}
				else{
					sensitive_items.add(sen_item);
				}
			}
		}
		return sensitive_items;
	}
	
	public void populate_relevant_transactions_database(String string) {
		BufferedWriter bufferedWriter = null;

		try {

			// Construct the BufferedWriter object
			bufferedWriter = new BufferedWriter(new FileWriter(string));

			for (Itemset temp_itemset : Main.list_of_relevant_transactions){
				
				for (Integer temp : temp_itemset.items){
					bufferedWriter.write(temp+" ");
				}
				bufferedWriter.newLine();

			}



						
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			// Close the BufferedWriter
			try {
				if (bufferedWriter != null) {
					bufferedWriter.flush();
					bufferedWriter.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			
		}
		
	}


}
